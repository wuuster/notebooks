import {AfterContentInit, Component, Input} from '@angular/core';

@Component({
  selector: 'app-books',
  templateUrl: './books.component.html',
  styleUrls: ['./books.component.scss']
})
export class BooksComponent implements AfterContentInit {
  public content: any;
  @Input() index = 0;
  @Input() order: any = 0;

  constructor() { }

  ngAfterContentInit(): void {
    this.content = sessionStorage.getItem('page_'+this.index);
  }

  saveContent(e: any){
   sessionStorage.setItem('page_'+this.index, e.target.value);
  }

  bringPageToFront(){
    const currentOrder =  Number(sessionStorage.getItem('order')) + 2 || 0;
    this.order = currentOrder;
    sessionStorage.setItem('order', String(currentOrder));
  }
}
