import {AfterViewInit, Component, ComponentFactoryResolver, ViewChild, ViewContainerRef} from '@angular/core';
import { BooksComponent } from './books/books.component';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements AfterViewInit  {
  public title = 'notebooks';
  public content = 'New Document';
  public _counter: number = 1;
  @ViewChild('container', { read: ViewContainerRef }) container: ViewContainerRef | any;
  constructor(private componentFactoryResolver: ComponentFactoryResolver) {
  }

  ngAfterViewInit (){
    setTimeout(() => {
      const numberOfPages = Number(sessionStorage.getItem('number_of_pages'));
      if (numberOfPages) {
        let times = 1;
        while (times <= numberOfPages) {
          this.add();
          times++;
        }
      }
    }, 0)
  }

  add(): void {
    if (this._counter <= 5) {
      const componentRef = this.container.createComponent(this.componentFactoryResolver.resolveComponentFactory(BooksComponent));
      sessionStorage.setItem('number_of_pages', String(this._counter));
      componentRef.instance.order = Number(sessionStorage.getItem('order')) + 1 || 0;
      componentRef.instance.index = this._counter++;
    }
  }

  reset(){
    sessionStorage.clear();
    location.reload();
  }
}
